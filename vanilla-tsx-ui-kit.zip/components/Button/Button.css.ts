import { style } from '@vanilla-extract/css'

export const button = style({
  padding: '10px 16px',
  backgroundColor: '#1e90ff',
  color: 'white',
  border: 'none',
  borderRadius: '6px',
  fontSize: '14px',
  cursor: 'pointer',
  selectors: {
    '&:hover': {
      backgroundColor: '#0d75d8',
    }
  }
})
