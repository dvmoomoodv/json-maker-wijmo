# Vanilla TSX UI Kit

프레임워크 독립적인 TSX 기반 UI 컴포넌트 라이브러리입니다.  
Vanilla Extract를 사용하여 정적 스타일을 적용하며 React, Vue, Solid 등에서 재사용이 가능합니다.

## 📦 구성
- ✅ `Button.tsx` + `Button.css.ts`
- ✅ Vite + Vanilla Extract 플러그인
- ✅ 타입 선언 포함

## 🚀 실행

```bash
pnpm install
pnpm dev
```
